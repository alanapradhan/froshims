<?php
/**
 *	This is an empty index page. 
 *	If you wish to edit the contents of the home page, please refer to home.php. 
*/
?>